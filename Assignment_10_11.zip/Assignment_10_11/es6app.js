window.onload = function () {

    var product = [
        { ProductId: 1, ProductName: 'Laptop', CategoryName: 'Electronics', Price: '50000', Manufacturer: 'ABC' },
        { ProductId: 2, ProductName: 'Mobile', CategoryName: 'other', Price: '50000', Manufacturer: 'PQR' },
        { ProductId: 3, ProductName: 'Camera', CategoryName: 'Electronics', Price: '50000', Manufacturer: 'LMN' },
        { ProductId: 4, ProductName: 'TV', CategoryName: 'others', Price: '50000', Manufacturer: 'PQR' },
        { ProductId: 5, ProductName: 'Computer', CategoryName: 'Electronics', Price: '50000', Manufacturer: 'ABC' },
        { ProductId: 6, ProductName: 'Desktop', CategoryName: 'other', Price: '50000', Manufacturer: 'PQR' },
        { ProductId: 7, ProductName: 'Mouse', CategoryName: 'Electronics', Price: '50000', Manufacturer: 'ABC' },
        { ProductId: 8, ProductName: 'CPU', CategoryName: 'Electronics', Price: '50000', Manufacturer: 'LMN' },
        { ProductId: 9, ProductName: 'Kitchen', CategoryName: 'Essential', Price: '50000', Manufacturer: 'XYZ' },
        { ProductId: 10, ProductName: 'Cloths', CategoryName: 'Essential', Price: '50000', Manufacturer: 'XYZ' },
    ];

    var space = "";
    var tbody = document.getElementById("tbdy");

    for (var i = 0; i < product.length; i++) {

        tbody.innerHTML += "<tr class='table-primary'><td>" + product[i].ProductId + "</td><td>" + product[i].ProductName + "</td><td>" + product[i].CategoryName + "</td><td>" + product[i].Price + "</td><td>" + product[i].Manufacturer + "</td></tr>";

    }

    var searchbtn = document.getElementById('searchbtn');
    var searchtxt = document.getElementById('searchtxt');
    var radiobtn1 = document.getElementById('radio1');
    var radiobtn2 = document.getElementById('radio2');
    var searchbtn = document.getElementById('searchbtn');

    radiobtn1.addEventListener('click', function () {
        createProductGroupByCatageoryName(product, 'CategoryName');

    }, false)

    radiobtn2.addEventListener('click', function () {
        createProductGroupByManufacturer(product, 'Manufacturer');

    }, false)


    searchbtn.addEventListener('click', function () {

        tbody.innerHTML = space;
        for (var i = 0; i < product.length; i++) {

            if ((product[i].CategoryName) === (searchtxt.value)) {

                tbody.innerHTML += "<tr class='table-primary'><td>" + product[i].ProductId + "</td><td>" + product[i].ProductName + "</td><td>" + product[i].CategoryName + "</td><td>" + product[i].Price + "</td><td>" + product[i].Manufacturer + "</td></tr>";

            }

        }

    }, false)


    function createProductGroupByCatageoryName(records, property) {
        let result = records.reduce((groupResult, record) => {
            console.log(`Current State ${JSON.stringify(groupResult)} and current record ${JSON.stringify(record)}`);
            let key = record[property];
            console.log(`Key of the record = ${key}`);
            if (!groupResult[key]) {

                groupResult[key] = [];

            }

            groupResult[key].push(record);
            console.log(`After match found for push state is = ${JSON.stringify(groupResult)}`);
            Products = [];
            for (let value of Object.values(groupResult)) {
                for (let product of value) {
                    Products.push(product);
                }
            }
            var tbody = document.getElementById("tbdy");
            tbody.innerHTML = "";
            for (var index = 0; index < Products.length; index++) {
                tbody.innerHTML += "<tr class='table-primary'><td>" + Products[index].ProductId + "</td><td>" + Products[index].ProductName + "</td><td>" + Products[index].CategoryName + "</td><td>" + Products[index].Price + "</td><td>" + Products[index].Manufacturer + "</td></tr>";
            }
            return groupResult;

        }, {});

        return result;
    };

    function createProductGroupByManufacturer(records, property) {
        let result = records.reduce((groupResult, record) => {
            console.log(`Current State ${JSON.stringify(groupResult)} and current record ${JSON.stringify(record)}`);
            let key = record[property];
            console.log(`Key of the record = ${key}`);
            if (!groupResult[key]) {
                groupResult[key] = [];


            }
            groupResult[key].push(record);

            console.log(`After match found for push state is = ${JSON.stringify(groupResult)}`);
            Products = [];
            for (let value of Object.values(groupResult)) {
                for (let product of value) {
                    Products.push(product);
                }
            }
            var tbody = document.getElementById("tbdy");
            tbody.innerHTML = "";
            for (var index = 0; index < Products.length; index++) {
                tbody.innerHTML += "<tr class='table-primary'><td>" + Products[index].ProductId + "</td><td>" + Products[index].ProductName + "</td><td>" + Products[index].CategoryName + "</td><td>" + Products[index].Price + "</td><td>" + Products[index].Manufacturer + "</td></tr>";
            }

            return groupResult;

        }, {});

        return result;
    };


}