import express from 'express';
import path from 'path';
import {fileURLToPath} from 'url';

const port = process.env.PORT || 7011;

const instance = express();


let __dirName = fileURLToPath(import.meta.url);

console.log("Directory name" + __dirName);

instance.use(
    express.static(path.join(__dirName, './node_modules/bootstrap/dist/css'))
); 

instance.use(
    express.static(path.join(__dirName, './node_modules/jquery/dist'))
); 
 

instance.use(
    express.static(path.join(__dirName, './../views'))
); 
 
let router = express.Router();

instance.use(router); 

router.get('/', (req,resp)=>{
    resp.sendFile('index.html', {
        root: path.join(__dirName, './../views')
    });
});

router.get('/department', (req,resp)=>{
    // response the home.html file
    resp.sendFile('department.html', {
        root: path.join(__dirName, './../views')
    });
});

router.get('/employee', (req,resp)=>{
    // response the index.html file
    resp.sendFile('employee.html', {
        root: path.join(__dirName, './../views')
    });
});

// 4. Start Listening on port
instance.listen(port, ()=>{
    console.log(`Server Started on Port ${port}`);
});