import express from "express";
import cors from 'cors';
import DataAccess from './dataacces/dataaccess.js';

const instance = express();


instance.use(express.json());
instance.use(express.urlencoded({extended:false}));
// add CORS middleware
instance.use(cors({
  origin: '*', 
  methods: '*',
  allowedHeaders: '*' 
}));

const port = process.env.PORT || 7013;
const dal = new DataAccess(); 

instance.get("/api/departments", dal.getDepartmentData);
instance.post("/api/departments",dal.postDepartmentData);
instance.put("/api/departments/:id",dal.putDepartmentData);
instance.delete("/api/departments/:id",dal.deleteDepartmentData);


instance.get("/api/employees",dal.getEmployeeData);
instance.post("/api/employees",dal.postEmployeeData);
instance.put("/api/employees/:id",dal.putEmployeeData);
instance.delete("/api/employees/:id",dal.deleteEmployeeData);

instance.get("/api/employees/:id",dal.fetchEmployeesByDeprartment);


instance.listen(port, () => {
    console.log(`Server Started on Port ${port}`);
  });
  