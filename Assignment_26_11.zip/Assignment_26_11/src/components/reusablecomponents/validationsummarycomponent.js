import React from 'react'

function validationsummarycomponent(props) {
    var data=props.data;
   // console.log("data :"+data);
    if(data.length===0 ||data===""){
        
        return (
            <div style={{color:'red'}}>
                field must be entered
            </div>
        )
    }
    else if(props.isText){

        var pattern = new RegExp(/[a-zåäö ]/i);
        if(pattern.test(props.data)){
           
            return(
                <div style={{color:'green'}}>
                        Correct
                    </div>)
        }
        else{
            
            return(
                <div style={{color:'red'}}>must be character</div>
            )
        }
        
        
    }
    else{
        
        return(
        <div style={{color:'green'}}>
                Correct
            </div>)
    }
    
}

export default validationsummarycomponent
