import EmployeeFormComponent from './../src/components/formcomponent/employeeformcomponent';
import DataGridComponent from './../src/components/reusablecomponents/datagridcomponent';
import DropdownComponent from './../src/components/reusablecomponents/dropdowncomponent';
// import EmployeeFormValidationComponent from './comp/formcomponent/employeeformcomponent'
 //import EmployeeFormComponent from './comp/formcomponent/formcomponentwithoutvalidation'
 import {
  BrowserRouter as Router,
  
  Route,
  Routes
  
} from "react-router-dom";
import Signup from './components/authentication/signup';
import Login from './components/authentication/login';
//import './App.css';

function App() {
  return (

    
      <Router>
         <Routes>
         <Route  path="/" element={<Signup/>}/>
         <Route  path="/login" element={<Login/>}/>
          <Route  path="/employee" element={<EmployeeFormComponent/>}/> 
        </Routes>
  
      </Router>
  
    // <div className="App">
    //  <EmployeeFormComponent></EmployeeFormComponent>
    // </div>


  );
}

export default App;
