import React,{useState} from 'react';
import DropdownComponent from '../reusablecomponents/dropdowncomponent';
import DataGridComponent from '../reusablecomponents/datagridcomponent';
const EmployeeFormComponent=()=>{
  const [employee, setEmployee] = useState({empno:0, empname:'', designation:'', salary:'', deptname:''});
  const [employees, addEmployee] = useState([]);
  const [designations, setDesig] = useState(['Manager', 'Clerk', 'Operator', 'Engineer']);
  const [departments, setDepts] = useState(['IT', 'HR', 'TR', 'SL', 'AC']);
  const [isDataValid, setValidations] = useState(true);
  const [isFormValid, setFormValidation] = useState(true);
 const [sortKey, setSortKey] = useState()
 const [groupKey, setGroupKey] = useState()
  // clear all HTML Editable elements
  const clear=()=>{
    setEmployee({empno:0, empname:'', designation:'', salary:'', deptname:''});
  };
  const sortValues=['Sort','empNo','empName','designation','salary','deptname'];
  const groupValues=['Group','deptname'];
  const save=()=>{
      // mutate the employees array by adding new employee in employees
      addEmployee([...employees, employee]);
      console.log("employees"+employee);
  }


  const getSelectedDesignation=(value)=>{
    setEmployee({...employee, designation:value});
  };

  const getSelectedDeptName=(value)=>{
    setEmployee({...employee, deptname:value});
  };

  const getSelectedSortKey=(value)=>{
    setSortKey(value);
  }
  const getSelectedGroupKey=(value)=>{
    setGroupKey(value);
  }

  function onDeleteClick(index){
    var a=employees.filter((e,i)=>{
      if(i!=index)
        return e;
    });
   console.log("here");
    addEmployee(a);
  }

  function changeDataSource(value){
    addEmployee(value);
    console.log("change valeu :"+employees);

  }
  return (
      <div className="container">
          <form name="frmEmp">
              
              <div className="form-group">
                  <label>EmpNo</label>
                  <input type="text" value={employee.empno} className="form-control" 
                //   required
                //     name="empno"
                //     pattern="[0-9]+"
                   onChange={(evt)=>{setEmployee({...employee, empno: parseInt(evt.target.value)})}}/>
              </div>
              <div className="form-group">
                  <label>EmpName</label>
                  <input type="text" value={employee.empname} className="form-control" 
                //   required
                //   pattern="^[A-Za-z]+" name="empname"
                  onChange={(evt)=>{setEmployee({...employee, empname: evt.target.value})}}/>
              </div>
              <div className="form-group">
                  <label>Designation</label>
                  {/* <select  value={employee.designation} className="form-control"
                   onChange={(evt)=>{setEmployee({...employee, designation: evt.target.value})}}
                  >
                      {
                          designations.map((ds,idx)=>(
                              <option key={idx} value={ds}>{ds}</option>
                          ))
                      }
                  </select> */}
                  <DropdownComponent dataSource={designations}
                   valueProperty={employee.designation}
                   getSelectedValue={getSelectedDesignation} 
                   ></DropdownComponent>
              </div>
              <div className="form-group">
                  <label>Salary</label>
                  <input type="text" value={employee.salary} className="form-control"
                //   required pattern="[0-9]+" minLength="4" maxLength="8"
                  name="salary"
                   onChange={(evt)=>{setEmployee({...employee, salary: parseInt(evt.target.value)})}}
                  />
              </div>
              <div className="form-group">
                  <label>Department Name</label>
                  {/* <select  value={employee.deptname} className="form-control"
                  onChange={(evt)=>{setEmployee({...employee, deptname: evt.target.value})}}
                  >
                      {
                          departments.map((dp,idx)=>(
                              <option key={idx} value={dp}>{dp}</option>
                          ))
                      }
                  </select> */}
                   <DropdownComponent dataSource={departments} 
                     valueProperty={employee.deptname}
                     getSelectedValue={getSelectedDeptName} 
                     ></DropdownComponent>
              </div>
              <div className="btn-group-sm">
                  <input type="button" value="New" className="btn btn-primary"
                   onClick={clear}/>
                  <input type="button" value="Save" className="btn btn-success"
                  onClick={save}/>
                  
              </div>
          </form>
          <hr/>
          {/* table */}
          <div style={{padding:30}}>
          <DropdownComponent dataSource={sortValues}
                   valueProperty={sortKey}
                   getSelectedValue={getSelectedSortKey} 
                   ></DropdownComponent>
           <DropdownComponent dataSource={groupValues}
                   valueProperty={groupKey}
                   getSelectedValue={getSelectedGroupKey} 
                   ></DropdownComponent>        
          <DataGridComponent 
            dataSource={employees}
            getSelectedRow={setEmployee}
            canDelete={true}
            handleDelete={onDeleteClick}
            canSort={true}
            sortKey={sortKey}
            canGroup={true}
            groupKey={groupKey}
            changeDataSource={changeDataSource} 
            pages={10}    
            ></DataGridComponent>
           </div>
      </div>
  );
};

export default EmployeeFormComponent;