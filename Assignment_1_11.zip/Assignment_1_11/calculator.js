function add(){
    return x+y;
}

function sub(){
    return x-y;
}

function mul(){
    return x*y;
}

function div(){
    return x/y;
}

function _x(){
    return document.getElementById(x);
}

function view(val){
    _('result').value+=val;
}

function clear(){
    _('result').value+="";
}

