
const DataGridComponent = (props) => {


    const rowClick = (row) => {
        props.getSelectedRow(row);
        console.log(`Selected Row ${JSON.stringify(row)}`);
    }



    const deleteRow=(row)=>{

        console.log(props.dataSource);

        for(let i =0;i<props.dataSource.length;i++){

            if(row == props.dataSource[i]){

                props.dataSource.splice(i,1);

            }

        }

    }
  


    if (props.dataSource === undefined || props.dataSource.length === 0) {
        return (
            <div className="container">
                <strong>
                    No records to display
                </strong>
            </div>
        );
    } else {
        // 1. read all keys

        let data;

        const columns = Object.keys(props.dataSource[0]);

        if (props.canSort && props.sortKey === 'empname') {

            data = props.dataSource;

            data = data.sort(function (a, b) {

                if(a.empname < b.empname) { return -1; }

                if(a.empname > b.empname) { return 1; }

                return 0;

            });

        } else {

            data = props.dataSource;

        }

        return (<table className="table table-bordered table-striped">

            <thead>
                <tr>
                    {

                        columns.map((c, i) => (
                            <th key={i}>
                                {c}
                            </th>
                        ))

                    }

                </tr>

            </thead>
            <tbody>
                {
                    props.dataSource.map((row, rIndex) => (
                        <tr key={rIndex} onClick={() => rowClick(row)}>
                            {
                                columns.map((col, cIndex) => (
                                    <td key={cIndex}>
                                        {row[col]}
                                    </td>

                                ))

                            }

                            {

                              //  <td value={props.canDelete}>
                               
                                 <td>

                                 <div><input className="btn btn-sm btn-danger" type="button" value="Delete" id="btnLoadData"  onClick={()=>deleteRow(row)}/></div>
 
                             </td>

                            }
                        </tr>
                    ))
                }
            </tbody>
        </table>);
    }


};

export default DataGridComponent;