
import { Sequelize } from "sequelize";
import pkg from "sequelize";
const { DataTypes } = pkg;

import department from "./../models/department.js";
import employees from "./../models/employee.js";

const sequelize = new Sequelize("masterDB", "poonam", "Blaze@123", {
  host: "localhost",
  port: 5432,
  dialect: "postgres",
});

sequelize.authenticate().then(
  (authenticate) => {
    console.log("====================================");
    console.log(`Connection Successful`);
    console.log("====================================");
  },
  (error) => {
    console.log(`Connection failed due to error occured: ${error.message}`);
  }
);

class DataAccess {
  constructor() {
    department.init(sequelize, DataTypes);
    employees.init(sequelize, DataTypes);
  }
  // Department wise CRUD operations
  async getDepartmentData(req, resp) {
    await sequelize.sync({ false: false });
    let records = await department.findAll();
    if (records) {
      return resp
        .status(200)
        .send({ message: "Data is received successfully", data: records });
    }
    return resp.status(500).send({ message: "Some error Occurred" });
  }
  async postDepartmentData(req, resp) {
    await sequelize.sync({ false: false });
    let dept = await department.create(req.body);
    if (dept) {
      return resp
        .status(200)
        .send({ message: "Data is added successfully", data: dept });
    }
    return resp
      .status(500)
      .send({ message: "Some error Occurred while adding record" });
  } 
  async putDepartmentData(req, resp) {
    await sequelize.sync({ false: false });
    let dept = await department.update(
      {
        deptno: req.body.deptno,
        deptname: req.body.deptname
      },
      {
        where: {
          deptno: parseInt(req.params.id),
        }
      }
    );

    if (dept) {
      return resp
        .status(200)
        .send({ message: "Data is updated successfully", data: dept });
    }
    return resp
      .status(500)
      .send({ message: "Some error Occurred while updating record" });
  }
  async deleteDepartmentData(req, resp) {
    await sequelize.sync({ false: false });
    let dept = await department.destroy({
      where: {
        deptno: parseInt(req.params.id),
      }
    });
    if (dept) {
      return resp
        .status(200)
        .send({ message: "Data is deleted successfully", data: dept });
    }
    return resp
      .status(500)
      .send({ message: "Some error Occurred while deleting record" });
  }

// Employees Wise CRUD Operations
  async getEmployeeData(req, resp) {
    await sequelize.sync({ false: false });
    let emps = await employees.findAll();
    if (emps) {
      return resp
        .status(200)
        .send({ message: "Data is received successfully", data: emps });
    }
    return resp.status(500).send({ message: "Some error Occurred" });
  }
  async postEmployeeData(req, resp) {
    await sequelize.sync({ false: false });
    let emps = await employees.create(req.body);
    if (emps) {
      return resp
        .status(200)
        .send({ message: "Data is added successfully", data: emps });
    }
    return resp
      .status(500)
      .send({ message: "Some error Occurred while adding record" });
  }

  async putEmployeeData(req, resp) {
    await sequelize.sync({ false: false });
    let emp = await employees.update({
      empno: req.body.empno,
      empName: req.body.empName,
      deptName: req.body.deptName,
      designation: req.body.designation,
      salary: req.body.salary
    }, {
      where: {
        empno: parseInt(req.params.id),
      }
    });
    if (emp) {
      return resp
        .status(200)
        .send({ message: "Data is updated successfully", data: emp });
    }
    return resp
      .status(500)
      .send({ message: "Some error Occurred while updating record" });
  }

  async deleteEmployeeData(req, resp) {
    await sequelize.sync({ false: false });

    let emp = await employees.destroy({
      where: {
        empno: parseInt(req.params.id),
      }
    });
    if (emp) {
      return resp
        .status(200)
        .send({ message: "Data is deleted successfully", data: emp });
    }
    return resp
      .status(500)
      .send({ message: "Some error Occurred while deleting record" });
  }

  // Deprartment wise employee search
  async fetchEmployeesByDeprartment(req, resp) {
    await sequelize.sync({ false: false });
    let employee = await employees.findOne({

      where:{
        deptname: req.params.id,
      }
    });
    if(employee){
      return resp
            .status(200)
            .send({message:"Data find successfully", data: employee});
    }
    return resp
          .status(404)
          .send({message: `Unable to find employees by department name : ${req.params.id}`});
  }
}

export default DataAccess;
