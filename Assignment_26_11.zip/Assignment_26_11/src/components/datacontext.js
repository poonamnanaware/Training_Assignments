// define a Global context object
import {createContext} from 'react'; 
// define a Global Object with the initial value

export const DataContext = createContext(null);