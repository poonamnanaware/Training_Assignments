function Logic(){
   var Employees=[];
    // private function that returs Departments
    function getDeps(){
        var departments = ['IT', 'HR', 'SL', 'AC'];
        return departments;
    }
    function getCourses(){
        var course = ['IT', 'HR', 'SL', 'AC'];
        return course;
    }
    function getColor(){
        var color = ['RED', 'YELLOW', 'GREEN', 'ORANGE'];
        return color;
    }
    function getEmployees(){
        return Employees;
    }
    function addEmployee(emp){
        Employees.push(emp);
        return Employees;
    }
    return {
        getDepartments: getDeps,
        getEmployees: getEmployees,
        addEmployee: addEmployee,
        getCourses:getCourses,
        getColor:getColor
    };
}