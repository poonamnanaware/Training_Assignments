import React,{useState} from 'react'
import { useNavigate } from "react-router-dom";
export default function Signup() {

    const [email, setemail] = useState();
    const [pass, setpass] = useState()

    const navigate = useNavigate();
    return (
        <div style={{padding:100}}>
            <div >Signup</div>
            <div style={{margin:20}}>
                <input type='text' placeholder='email' onChange={(evt)=>setemail(evt.target.value)}/>
            
            </div>
            <div style={{margin:20}}>
                <input type='text' placeholder='password' onChange={(evt)=>setpass(evt.target.value)}/>
            
            </div>
            <button style={{margin:20}} onClick={()=> {
    navigate('/login', { state: {email,pass} })
  }}>signup</button>
           
        </div>
    )
}
