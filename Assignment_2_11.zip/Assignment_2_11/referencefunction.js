var MyObject = function () {


    this.getBlankSpaces = function (str) {
        var spaceCount = (str.split(" ").length - 1);
        console.log(spaceCount)
        return spaceCount;

    };

    this.getStatements = function (str) {
        var getStatementsCount = (str.match(RegExp(`[.]`, 'gi')) || []).length;
        console.log(getStatementsCount)
        return getStatementsCount;

    };

    this.getCommas = function (str) {
        var getCommasCount = (str.split(",").length - 1);
        console.log(getCommasCount)
        return getCommasCount;

    };

    this.titleCase = function (str) {
        var sentence = str.toLowerCase().split(" ");
        for (var i = 0; i < sentence.length; i++) {
            sentence[i] = sentence[i][0].toUpperCase() + sentence[i].slice(1);
        }
        return sentence;
    }

    this.getWordCount = function (str) {
        //    \w+    between one and unlimited word characters
        //    /g     greedy - don't stop after the first match
        console.log("Inside get count.....");
        var cnt;
        var cnt = str.match(/(\w+)/g).length;
        // var str1= str.split(" ");
        // for (var i = 0; i < str1.length; i++){
        //     if (str1[i] != " "){
        //         cnt =+1;
        //     }
        //     cnt =+1;

        // }
        // console.log("printing cnt......" +cnt);
        return cnt;

    };

    this.getVowelsCount = function (str) {
        var index = [];
        var cnt = 0;
        for (i = 0; i < str.length; i++) {
            if ((str[i] == "a") || (str[i] == "e") || (str[i] == "i") || (str[i] == "o") || (str[i] == "u")) {
               // console.log("Vowel...." + {[i]:str[i]});
                
               // console.log("Vowel Posotion" + i);
                cnt += 1;
            }
        }
        return cnt;
    }

    this.getSpecificWordCount = function (str, word) {
        var getSpecificWordCount = (str.split(word).length - 1);
        return getSpecificWordCount;
    };

    this.getVowelsCountWithPos = function (str) {
        var index = [];
        var content;
        if (str[i] == 'a' || str[i] == 'e' || str[i] == 'i' || str[i] == 'o' || str[i] == 'u' || str[i] == 'a' || str[i] == 'E' || str[i] == 'I' || str[i] == 'O' || str[i] == 'U') {

            index.push({ [i]: str[i] });

        }

        for (var j = 0; j <= index.length; j++) {

            var temp = index[j];

            content += temp;

            console.log("getVowelsCountWithPos..........." + content);

        }
    }


};


